const express = require('express');
const router = express.Router();
const controller = require('../controllers/earningsController');

router.post('/add', controller.addTransaction);          // 1
router.get('/all', controller.getAllTransactions);       // 2
router.get('/:userId', controller.getEarningsByUser);    // 3
router.delete('/:id', controller.deleteTransaction);     // 4

module.exports = router;
