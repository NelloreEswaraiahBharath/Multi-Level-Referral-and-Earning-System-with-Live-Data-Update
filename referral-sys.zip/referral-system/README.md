# Referral and Earnings Backend

## Setup

1. `npm install`
2. Ensure MongoDB is running
3. Set `.env` with your Mongo URI
4. `npm start`

## API

- POST `/api/earnings/add`
```json
{
  "userId": "USER_ID",
  "amount": 1500
}
```

Supports 5% direct and 1% indirect earnings for purchases ≥ 1000.

MONGO_URI = your_mongodb_uri_here 