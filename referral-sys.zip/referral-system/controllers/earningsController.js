const User = require('../models/User');
const Transaction = require('../models/Transaction');
const { calculateReferralEarnings } = require('../utils/referralCalculator');

const Earning = require('../models/earningsModel');

exports.addTransaction = async (req, res) => {
  try {
    const newEarning = new Earning(req.body);
    const saved = await newEarning.save();
    res.status(201).json(saved);
  } catch (error) {
    res.status(500).json({ error: 'Failed to add earning' });
  }
};

exports.getAllTransactions = async (req, res) => {
  try {
    const earnings = await Earning.find();
    res.status(200).json(earnings);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch earnings' });
  }
};

exports.getEarningsByUser = async (req, res) => {
  try {
    const earnings = await Earning.find({ userId: req.params.userId });
    res.status(200).json(earnings);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch user earnings' });
  }
};

exports.deleteTransaction = async (req, res) => {
  try {
    await Earning.findByIdAndDelete(req.params.id);
    res.status(200).json({ message: 'Transaction deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete transaction' });
  }
};
