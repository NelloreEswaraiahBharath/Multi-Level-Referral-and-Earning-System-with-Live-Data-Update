const User = require('../models/User');

const earningsLog = [];

const calculateReferralEarnings = async (user, amount) => {
    let parent = user.referredBy;
    let level = 1;
    while (parent && level <= 2) {
        const percentage = level === 1 ? 0.05 : 0.01;
        const earnings = amount * percentage;
        earningsLog.push({ to: parent.toString(), from: user._id.toString(), level, earnings });
        parent = (await User.findById(parent)).referredBy;
        level++;
    }
    console.log("Earnings Log:", earningsLog);
};

module.exports = { calculateReferralEarnings };
